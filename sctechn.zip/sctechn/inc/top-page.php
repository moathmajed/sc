<section class="top-page">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="text">
                    <h1>
                        Page Name
                    </h1>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Start Solutions -->
<section class="solutions">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12">
                <div class="text">
                    <h3>
                        our solutions
                    </h3>
                    <p>
                    In a laoreet purus. Integer turpis quam, laoreet id orci nec, ultrices lacinia nunc. Aliquam erat volutpat. Curabitur fringilla in purus eget egestas. Etiam quis.
                    </p>
                    <a href="#" class="btn btn-blue">all solutions</a>
                </div>
            </div>
            <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12">
                        <div class="s-item">
                            <div class="image">
                                <img src="./img/service-img-1.png" alt="">
                            </div>
                            <div class="overlay">
                                <div class="text">
                                    <a href="#">
                                        <span>
                                            lighting design
                                        </span>
                                        <span>
                                            <i class="fas fa-arrow-right"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12">
                        <div class="s-item">
                            <div class="image">
                                <img src="./img/service-img-2.png" alt="">
                            </div>
                            <div class="overlay">
                                <div class="text">
                                    <a href="#">
                                        <span>
                                            audio systems
                                        </span>
                                        <span>
                                            <i class="fas fa-arrow-right"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12">
                        <div class="s-item">
                            <div class="image">
                                <img src="./img/service-img-3.png" alt="">
                            </div>
                            <div class="overlay">
                                <div class="text">
                                    <a href="#">
                                        <span>
                                            broadcast engineering
                                        </span>
                                        <span>
                                            <i class="fas fa-arrow-right"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Solutions -->
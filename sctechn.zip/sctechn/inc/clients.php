<!-- Start Clients -->
<section class="clients">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="text">
                    <h3>
                        our clients
                    </h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="clients-slider swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide c-item">
                            <img src="./img/partner-img-1.png" alt="">
                        </div>
                        <div class="swiper-slide c-item">
                            <img src="./img/partner-img-2.png" alt="">
                        </div>
                        <div class="swiper-slide c-item">
                            <img src="./img/partner-img-3.png" alt="">
                        </div>
                        <div class="swiper-slide c-item">
                            <img src="./img/partner-img-4.png" alt="">
                        </div>
                        <div class="swiper-slide c-item">
                            <img src="./img/partner-img-5.png" alt="">
                        </div>
                    </div>
                    <br>
                    <br>
                    <br>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Clients -->
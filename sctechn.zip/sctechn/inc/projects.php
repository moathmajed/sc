<!-- Start Projects -->
<section class="latest-projects">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                <div class="text">
                    <h3>
                        latest projects
                    </h3>
                    <p>
                    In a laoreet purus. Integer turpis quam, laoreet id orci nec, ultrices lacinia nunc. Aliquam erat volutpat. Curabitur fringilla in purus eget egestas. Etiam quis.
                    </p>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                <div class="p-item">
                    <a href="#">
                        <img src="./img/project-img-1.png" alt="">
                    </a>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                <div class="p-item">
                    <a href="#">
                        <img src="./img/project-img-2.png" alt="">
                    </a>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                <div class="p-item">
                    <a href="#">
                        <img src="./img/project-img-3.png" alt="">
                    </a>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                <div class="p-item">
                    <a href="#">
                        <img src="./img/project-img-4.png" alt="">
                    </a>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                <div class="p-item">
                    <a href="#">
                        <img src="./img/project-img-5.png" alt="">
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="btn-wrapper">
                    <a href="#" class="btn btn-blue">all projects</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Projects -->
<?php include "header.php"?>
<?php include "./inc/top-page.php"?>

<!-- Start Page -->
<div id="single-page" class="page">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="image">
                    <img src="./img/about-img.png" alt="">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="content">
                    <h1>heading 1</h1>
                    <h2>heading 1</h2>
                    <h3>heading 1</h3>
                    <h4>heading 1</h4>
                    <h5>heading 1</h5>
                    <h6>heading 1</h6>
                    <p>
                    Vestibulum eu quam nec neque pellentesque efficitur id eget nisl. Proin porta est convallis lacus blandit pretium sed non enim. Maecenas lacinia non orci at aliquam. Donec finibus, urna bibendum ultricies laoreet, augue eros luctus sapien, ut euismod leo tortor ac enim. In hac habitasse platea dictumst. Sed cursus venenatis tellus, non lobortis diam volutpat sit amet. Sed tellus augue, hendrerit eu rutrum in, porttitor at metus. Mauris ac hendrerit metus. Phasellus mattis lectus commodo felis egestas, id accumsan justo ultrices. Phasellus aliquet, sem a placerat dapibus, enim purus dictum lacus, nec ultrices ante dui ac ante. Phasellus placerat, urna.
                    </p>
                    <p>
                    Vestibulum eu quam nec neque pellentesque efficitur id eget nisl. Proin porta est convallis lacus blandit pretium sed non enim. Maecenas lacinia non orci at aliquam. Donec finibus, urna bibendum ultricies laoreet, augue eros luctus sapien, ut euismod leo tortor ac enim. In hac habitasse platea dictumst. Sed cursus venenatis tellus, non lobortis diam volutpat sit amet. Sed tellus augue, hendrerit eu rutrum in, porttitor at metus. Mauris ac hendrerit metus. Phasellus mattis lectus commodo felis egestas, id accumsan justo ultrices. Phasellus aliquet, sem a placerat dapibus, enim purus dictum lacus, nec ultrices ante dui ac ante. Phasellus placerat, urna.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Page -->

<?php include "footer.php"?>